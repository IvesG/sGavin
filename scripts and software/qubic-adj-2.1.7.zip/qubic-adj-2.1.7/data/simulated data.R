## simulated data  #3
y1 <-c(rnorm(100,5.5,0.2),rnorm(70,6.5,0.1),rnorm(130,7.5,0.2))

y2 <-c(rnorm(200,0.2,0.4),rnorm(100,2.5,0.3))

y3 <-c(rnorm(60,0,1),rnorm(90,2,0.3),rnorm(150,4,0.5))

y4 <-c(rnorm(40,3.5,0.1),rnorm(80,5.5,0.1),rnorm(50,6.5,0.1),rnorm(30,7.5,0.2))

y5 <-c(rnorm(140,0.2,0.4),rnorm(160,2.5,0.3))

y6 <-c(rnorm(90,0,1),rnorm(90,2,0.3),rnorm(120,4,0.5))

y7 <-c(rnorm(40,0.2,0.4),rnorm(60,2.5,0.3),rnorm(80,1,0.2),rnorm(120,5,0.2))

y8 <-c(rnorm(90,0,1),rnorm(90,2,0.3),rnorm(120,4,0.5))

z <-rbind(y1,y2,y3,y4,y5,y6,y7,y8)
rownames(z)<-paste("gene",1:8,sep="_")
colnames(z) <- paste("cond",1:300,sep="_")



write.table(z,"simulated3.csv",sep=",")